import React from 'react';
import {useState, useEffect} from 'react'
import './users.css';

function Users() {
    const [listaUsers, setEquipos] = useState(["",{count: "", ultimoUser: "", users: ""}])
    useEffect(() => {
        obtenerDatos()    
    }, [])

    const obtenerDatos = async () => {
        const data = await fetch("http://localhost:9000/api/users")
        const users = await data.json()
        setEquipos(users)
        console.log(users)
    }
    
    return (  
        <div className="div-users-contenedor">
            <div className="section-users">
                <section className="section-users-cantidad">
                    <h2>Cantidad de Usuarios:</h2>
                    {
                        <p>{listaUsers[0].count}</p>
                    }
                </section>
                <section className="section-users-ultimo">
                    <h2>Ultimo usuario creado:</h2>
                    {
                        <p>{listaUsers[0].ultimoUser}</p>
                    }
                </section>
            </div>
            {              
                listaUsers[0].users?.map((producto, i) => {
                    return (
                        <div className="div-users" key={producto.id}>                 
                                <span key={producto.id}>{producto.id}</span>
                                <span  key={producto.nombre}>{producto.nombre}</span>
                                <span  key={producto.apellido}>{producto.apellido}</span>
                                <span  key={producto.email}>{producto.email}</span>
                                <a href={producto.imageURL} key={producto.imageURL}>Link</a>                                
                        </div>
                    )                                      
                })          
            }      
        </div>
 )
}

export default Users;

import React from 'react';
import {Link, Route} from 'react-router-dom'
import './Navbar.css';

function Navbar(){
    return (

        <header className="section-header">
            <Link to="/"> Home   | </Link>
            <Link to="/products"> Products   | </Link>
            <Link to="/users"> Users    |</Link>
            <a href="http://localhost:9000/"> Ewine    </a>
        </header>
    )   
    
}

export default Navbar;
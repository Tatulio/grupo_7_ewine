import React from 'react';
import {useState, useEffect} from 'react'
import './products.css';



function Products() {
    const [listaProductos, setEquipos] = useState(["",{count: "", products: ""}])
    useEffect(() => {
        obtenerDatos()    
    }, [])

    const obtenerDatos = async () => {
        const data = await fetch("http://localhost:9000/api/products")
        const users = await data.json()
        setEquipos(users)    
        console.log(users)
        
    }
    

  
    return (
        

        <div className="div-productos">
            <section className="section-productos">
                <span className="span-productos">ID</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">NOMBRE</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">AÑO</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">Varietal</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">Bodega</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">Tipo vino</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">Precio</span>
                <hr className="hr-productos-vertical"></hr>
                <span className="span-productos">URL Producto</span>
                  
            </section>
            <hr className="hr-productos-horizontal"></hr>
            
            
            {
                
                listaProductos[0].products?.map((producto, i) => {
                    return (
                        
                        
                        <section className="section-productos" key={producto.id}>
                            <span className="span-productos">{producto.id}</span>
                            <hr className="hr-productos-vertical"></hr>
                            <span className="span-productos">{producto.name}</span>
                            <hr className="hr-productos-vertical"></hr>
                            <span className="span-productos">{producto.anno}</span>
                            <hr className="hr-productos-vertical"></hr>
                            <span className="span-productos">{producto['tipoVarietal.name']}</span>
                            <hr className="hr-productos-vertical"></hr>
                            <span className="span-productos">{producto['tipoBodega.name']}</span>
                            <hr className="hr-productos-vertical"></hr>  
                            <span className="span-productos">{producto['tipoVino1.name']}</span>
                            <hr className="hr-productos-vertical"></hr>  
                            <span className="span-productos">{producto.price}</span>
                            <hr className="hr-productos-vertical"></hr>  
                            <a className="span-productos" href="{producto.imageURL}">LINK</a>
                               
                        </section>
                        
                        
                    )
                })
            }   
             
        </div>
 )
}

export default Products;

{/* <p className="p-productos">{producto["tipoVino1.name"]}</p>
                            <p className="p-productos">{producto["tipoBodega.name"]}</p>
                            <p className="p-productos">{producto["tipoVarietal.name"]}</p>
                            <a className="p-productos" href={producto.imageURL}>LINK Producto</a> */}
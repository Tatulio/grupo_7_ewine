import React from 'react';
import {useState, useEffect} from 'react'
import './products.css';

var sar = ["",{count: "", products: "", counCat:{Malbec: 0, CabernetSauvignon: 0, Merlot: 0, Syrah: 0, Chardonnay: 0, SauvignonBlanc: 0, PinotNoir: 0}, ultimoProducto: ""}]

function Products() {
    const [listaProductos, setEquipos] = useState(["",{count: "", countCat:{Malbec: 0, CabernetSauvignon: 0, Merlot: 0, Syrah: 0, Chardonnay: 0, SauvignonBlanc: 0, PinotNoir: 0}, products: "",  ultimoProducto: ""}])
    useEffect(() => {
        obtenerDatos()    
    }, [])

    const obtenerDatos = async () => {
        const data = await fetch("http://localhost:9000/api/products")
        const users = await data.json()
        setEquipos(users)
        
    }
    
    return (
        
        <div className="div-productos-contenedor">
                           <div className="section-producto">
                <section className="section-productos-cantidad">
                    <h2>Cantidad de Productos:</h2>
                    {
                        <p>{listaProductos[0].count}</p>
                    }
                </section>
                <section className="section-productos-ultimo">
                    <h2>Ultimo Producto:</h2>
                    {
                        <p>{listaProductos[0].ultimoProducto}</p>
                    }
                </section>
            </div>
            {              
                listaProductos[0].products?.map((producto, i) => {
                    return (
                        <div className="div-productos" key={producto.id}>                 
                                <span key={producto.id}>{producto.id}</span>
                                <span  className="span-name" key={producto.name}>{producto.name}</span>
                                <span  key={producto.price}>{producto.price}</span>
                                <span  key={producto['tipoVarietal.name']}>{producto['tipoVarietal.name']}</span>
                                <span  key={producto['tipoVino1.name']}>{producto['tipoVino1.name']}</span>
                                <span  key={producto['tipoBodega.name']}>{producto['tipoBodega.name']}</span>
                                <a href={producto.imageURL} key={producto['tipoBodega.name']}>Link</a>
                                
                        </div>
                    )
                   
                    
                })
            
               
            
            }   
         
        </div>
 )
}

export default Products;

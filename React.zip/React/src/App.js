import {useState } from 'react';
import './App.css';
import {Route, BrowserRouter, Link, Routes} from 'react-router-dom'
import Products from './products';
import Navbar from './Navbar'
import Home from './Home'
import {Grid, Box} from '@material-ui/core'




function App() {
  
 return (
    
    <div className="App">
      <Navbar />
      <Routes>
        <Route exact path="/products" element={<Products />}/>
        <Route exact path='/users' element={<Products />}/>
        <Route exact path='/' element={<Home />}/>  
      </Routes>
    </div>
  );
}

export default App;

import React from 'react';
import {Link, Route} from 'react-router-dom'
import './Navbar.css';

function Home(){
    return (

        <div className="home">
                <picture className="logo">
            <a href="http://localhost:9000/"><img  className="logo-copa" src="/images/logo.png" alt="icono"></img></a>
            </picture>
           <p className="dashboard">DASHBOARD</p>
        </div>
    )   
    
}

export default Home;